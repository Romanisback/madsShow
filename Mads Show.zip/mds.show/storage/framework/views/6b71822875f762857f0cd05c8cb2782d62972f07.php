<div class="loader">
    <div class="pre_loader_inner"></div>
    <div class="loader_inner"><img src="/html/assets/images/Slogo.svg" alt="Logo"></div>
</div>
<?php /**PATH /var/www/u1109349/data/www/mds.show/resources/views/site/layouts/blocks/_loader.blade.php ENDPATH**/ ?>