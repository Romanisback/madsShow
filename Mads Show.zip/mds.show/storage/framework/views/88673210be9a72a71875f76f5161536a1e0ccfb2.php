<?php $__env->startSection('title', 'Clients'); ?>

<?php $__env->startSection('content'); ?>
    <header class="page-header">
        <h2>Clients</h2>
        <a href="<?php echo e(route('admin.clients.create')); ?>" class="mb-xs mt-xs mr-xs btn btn-primary pull-right">
            <i class="fa fa-plus-circle" aria-hidden="true"></i> Создать
        </a>
    </header>

    <div class="row">
        <div class="col-md-12">
            <section class="panel panel-dark">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>

                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered mb-none">
                            <thead>
                            <tr>
                                <th width="50px">#</th>
                                <th width="160px">Изображение</th>
                                <th>Название</th>
                                <th>Ссылка</th>
                                <th width="50px"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($client->id); ?></td>
                                    <td><img src="<?php echo e(url('storage/' . $client->image)); ?>" width="150" alt=""></td>
                                    <td class="text-weight-bold"><?php echo e($client->name); ?></td>
                                    <td><?php echo e($client->url); ?></td>
                                    <td class="actions text-center">
                                        <a href="<?php echo e(route('admin.clients.edit', ['id' => $client->id])); ?>"><i class="fa fa-pencil"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <!-- pagination -->
                        <?php echo e($clients->appends( request()->query() )->links()); ?>

                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u1109349/data/www/mds.show/resources/views/admin/clients/list.blade.php ENDPATH**/ ?>