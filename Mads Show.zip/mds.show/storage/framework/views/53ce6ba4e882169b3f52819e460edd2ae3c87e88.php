<!doctype html>
<html class="fixed" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="keywords" content="Admin Template" />
    <meta name="description" content="Admin">
    <meta name="author" content="">

    <title><?php echo e(config('app.admin')); ?> - <?php echo $__env->yieldContent('title'); ?></title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <link rel="icon" href="<?php echo e(asset('adm/images/favicon.ico')); ?>" type="image/png">

    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="<?php echo e(asset('adm/vendor/bootstrap/css/bootstrap.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('adm/vendor/font-awesome/css/font-awesome.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('adm/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('adm/css/theme.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('adm/css/theme-custom.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('adm/css/skins/default.css')); ?>" />

    <script src="<?php echo e(asset('adm/vendor/modernizr/modernizr.js')); ?>"></script>
</head>
<body>
    <section class="body">

        <?php echo $__env->make('admin.layouts.blocks._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="inner-wrapper">
            <?php echo $__env->make('admin.layouts.blocks._aside_left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <section role="main" class="content-body">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </div>


    </section>

    <?php echo $__env->yieldPushContent('modals'); ?>

    <!-- Vendor -->
    <script src="<?php echo e(asset('adm/vendor/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('adm/vendor/jquery-browser-mobile/jquery.browser.mobile.js')); ?>"></script>
    <script src="<?php echo e(asset('adm/vendor/bootstrap/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('adm/vendor/nanoscroller/nanoscroller.js')); ?>"></script>
    <script src="<?php echo e(asset('adm/vendor/jquery-placeholder/jquery.placeholder.js')); ?>"></script>
    <script src="<?php echo e(asset('adm/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js')); ?>"></script>

    <script src="<?php echo e(asset('adm/js/theme.js')); ?>"></script>

    <script src="<?php echo e(asset('adm/js/theme.custom.js')); ?>"></script>
    <script src="<?php echo e(asset('adm/js/theme.init.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH /var/www/u1109349/data/www/mds.show/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>