<?php $__env->startSection('title', 'Order edit'); ?>

<?php $__env->startSection('content'); ?>
    <header class="page-header">
        <h2>Order / Edit</h2>
    </header>

    <?php echo $__env->make('admin.components._alert_messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row">
        <div class="col-md-12">
            <form class="" action="<?php echo e(route('admin.orders.edit', ['id' => $order->id])); ?>" enctype="multipart/form-data" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-8">
                        <section class="panel panel-dark">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name" class="control-label">Имя</label>
                                            <input type="text" id="name" name="name" value="<?php echo e(old('name', $order->name)); ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="email" class="control-label">Email</label>
                                            <input type="text" id="email" name="email" value="<?php echo e(old('email', $order->email)); ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="message" class="control-label">Сообщение</label>
                                            <textarea name="message"
                                                      id="message"
                                                      class="form-control description" rows="5"><?php echo e(old('message', $order->message)); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>

                    <div class="col-md-4">
                        <section class="panel panel-dark">
                            <div class="panel-body">
                                <div class="row">

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="status" class="control-label">Статус</label>
                                            <select class="form-control mb-md" id="status" name="status">
                                                <?php $__currentLoopData = \App\Models\Order::$getStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>" <?php echo e($order->status == $key ? 'selected' : null); ?>><?php echo e($status[0]); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="value" class="control-label">Бюджет</label>
                                            <input type="text" id="value" name="value" value="<?php echo e(old('value', $order->value)); ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="view" class="control-label">Просмотры</label>
                                            <input type="text" id="view" name="view" value="<?php echo e(old('view', $order->view)); ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="click" class="control-label">Клики</label>
                                            <input type="text" id="click" name="click" value="<?php echo e(old('click', $order->click)); ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>

                <footer class="panel-footer">
                    <div class="row">
                        <div class="col-md-6">
                            <a href="<?php echo e(route('admin.orders.list')); ?>" class="btn btn-primary"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i> Назад</a>
                            <button class="btn btn-success"><i class="fa fa-save" aria-hidden="true"></i> Сохранить</button>
                        </div>
                        <div class="col-md-6 text-right">
                            <a href="<?php echo e(route('admin.orders.delete', ['id' => $order->id])); ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i> Удалить</a>
                        </div>
                    </div>
                </footer>
            </form>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u1109349/data/www/mds.show/resources/views/admin/orders/edit.blade.php ENDPATH**/ ?>