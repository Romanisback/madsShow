<?php $__env->startSection('title', 'Отзывы'); ?>

<?php $__env->startSection('content'); ?>
    <div class="review animate__animated animate__fadeInLeft" id="reviews ">
        <div class="review_container">
            <div class="container">
                <h2>Отзывы</h2>
                <ul class="review-slider">
                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="text">
                                <p><?php echo e($review->review); ?></p>
                            </div>
                            <div class="user_photo">
                                <img src="<?php echo e(asset('storage/' . $review->avatar)); ?>" data-src="" alt="<?php echo e($review->id); ?>">
                            </div>
                            <div class="review_social_links">
                                <a href="<?php echo e($review->url); ?>" target="_blank"><img src="<?php echo e(asset('dist/assets/images/vk.svg')); ?>" alt="vk"></a>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u1109349/data/www/mds.show/resources/views/site/reviews.blade.php ENDPATH**/ ?>