<?php $__env->startSection('title', 'Главная страница'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Add agency -->
    <div class="agency" id="agency">
        <div class="container">
            <div class="container_content">
                <div class="agency__first-item">
                    <h1 class="h1-agency animate__animated animate__fadeIn">Mads Show</h1>
                    <p class="p-agency animate__animated animate__fadeIn">Маркетинговое агентство, объединяющее бизнес и
                        людей. Мы занимаемся продвижением брендов крупнейших организаций: Skillbox, World of Tanks, Raid: Shadow Legends, Zaka-zaka и др. А также помогаем блогерам найти рекламу на их каналы.</p>
                </div>
                <div class="agency__second-item animate__animated animate__fadeIn">
                    <img src="/assets/images/main/female.svg" alt="female" loading="lazy">
                    <img src="/assets/images/main/male-xxx.svg" alt="male-xxx" loading="lazy">
                    <img src="/assets/images/main/female-right.svg" alt="female-right" loading="lazy">
                </div>
            </div>
        </div>
    </div><!-- ./agency -->

    <div class="blogers animate__animated animate__fadeIn" id="blogers">
        <div class="container">
            <div class="blogers_section">
                <h2 class="h2-blogers animate__animated animate__fadeInUp">Наши блогеры</h2>
                <p class="p-blogers animate__animated animate__fadeInUp">Проводя рекламные кампании, мы индивидуально
                    подбираем подходящих блогеров, учитывая: целевую аудиторию, пол, возраст и интересы.</p>

                <!-- SLIDER BLOGERS -->

                <div class="slider-blogers">
                    <?php $__currentLoopData = $bloggers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($blogger->url); ?>">
                            <img src="<?php echo e(asset('storage/' . $blogger->image)); ?>" alt="<?php echo e($blogger->name); ?>">
                            <div class="title"><?php echo e($blogger->name); ?></div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u1109349/data/www/mds.show/resources/views/site/index.blade.php ENDPATH**/ ?>