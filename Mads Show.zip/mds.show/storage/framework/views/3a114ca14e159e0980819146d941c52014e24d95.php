<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
    <header class="page-header">
        <h2>Orders</h2>
    </header>

    <div class="row">
        <div class="col-md-12">
            <section class="panel panel-dark">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>

                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered mb-none">
                            <thead>
                            <tr>
                                <th width="50px">#</th>
                                <th>Имя</th>
                                <th>Email</th>
                                <th>Сообщение</th>
                                <th>Бюджет</th>
                                <th>Просмотры</th>
                                <th>Клики</th>
                                <th>Статус</th>
                                <th>Дата</th>
                                <th width="50px"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->id); ?></td>
                                    <td class="text-weight-bold"><?php echo e($order->name); ?></td>
                                    <td><?php echo e($order->email); ?></td>
                                    <td><?php echo e($order->message); ?></td>
                                    <td><?php echo e($order->value); ?></td>
                                    <td><?php echo e($order->view); ?></td>
                                    <td><?php echo e($order->click); ?></td>
                                    <td><?php echo $order->statusUI; ?></td>
                                    <td><?php echo e($order->created_at->format('d-m-Y')); ?></td>
                                    <td class="actions text-center">
                                        <a href="<?php echo e(route('admin.orders.edit', ['id' => $order->id])); ?>"><i class="fa fa-pencil"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <!-- pagination -->
                        <?php echo e($orders->appends( request()->query() )->links()); ?>

                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u1109349/data/www/mds.show/resources/views/admin/orders/list.blade.php ENDPATH**/ ?>