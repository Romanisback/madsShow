<?php $__env->startSection('title', 'Кейсы'); ?>

<?php $__env->startSection('content'); ?>
    <div class="cases">
        <div class="container">
            <h2>Кейсы</h2>
            <div class="cases-slider animate__animated animate__fadeIn">

                <?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-container ">
                        <div class="item animate__animated animate__fadeIn" style="background: url(<?php echo e(asset('storage/' .$case->image)); ?>)">
                            <div class="item_child">
                                <img src="<?php echo e(asset('storage/' . $case->logo)); ?>" alt="<?php echo e($case->title); ?>">
                                <div class="case-info">
                                    <div class="company">
                                        <p><?php echo e($case->title); ?></p>
                                        <p><?php echo e($case->gained_result); ?></p>
                                    </div>
                                    <p class="company_rk-info">
                                        <?php echo e($case->description); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u1109349/data/www/mds.show/resources/views/site/cases.blade.php ENDPATH**/ ?>