<?php $__env->startSection('title', 'Наши клиенты'); ?>

<?php $__env->startSection('content'); ?>
    <div class="clients animate__animated animate__fadeInLeft" id="clients">
        <div class="container">
            <h2>Наши клиенты</h2>
            <ul class="clients-slider">
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e($client->url); ?>" target="_blank">
                            <img src="<?php echo e(asset('storage/' . $client->image)); ?>" alt="<?php echo e($client->name); ?>" loading="lazy">
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u1109349/data/www/mds.show/resources/views/site/clients.blade.php ENDPATH**/ ?>