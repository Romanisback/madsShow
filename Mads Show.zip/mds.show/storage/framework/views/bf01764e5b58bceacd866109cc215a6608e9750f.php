<?php if($errors->any()): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        </div>
    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/u1109349/data/www/mds.show/resources/views/admin/components/_alert_messages.blade.php ENDPATH**/ ?>