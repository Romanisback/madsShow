<div class="loader">
    <div class="pre_loader_inner"></div>
    <div class="loader_inner"><img src="/html/assets/images/Slogo.svg" alt="Logo"></div>
</div>
