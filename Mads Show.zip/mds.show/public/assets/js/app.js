console.log('MADS JS LOADED!!');

$(document).ready(function(){

    $(".loader_inner").fadeOut();
    $(".loader").delay(10).fadeOut("slow");
  

  })
